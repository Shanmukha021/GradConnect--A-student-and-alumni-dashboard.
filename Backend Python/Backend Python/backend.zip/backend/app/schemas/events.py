from pydantic import BaseModel, Field
from typing import Optional
from uuid import UUID

class EventBase(BaseModel):
    title: str
    description: Optional[str] = None
    type: str
    start_date: str
    end_date: Optional[str] = None
    location: str
    max_attendees: Optional[int] = None
    image_url: Optional[str] = None
    organizer_id: Optional[UUID] = None
    is_public: bool = True
    requires_approval: bool = False

class EventCreate(EventBase):
    pass

class EventUpdate(EventBase):
    pass

class EventResponse(EventBase):
    id: UUID
    created_at: str
    updated_at: str

    class Config:
        orm_mode = True
