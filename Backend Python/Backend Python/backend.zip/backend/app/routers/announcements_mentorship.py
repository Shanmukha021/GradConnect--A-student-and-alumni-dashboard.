
from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from ..models.announcements_mentorship import Announcement
from ..database import get_db
from ..schemas.announcements import AnnouncementCreate, AnnouncementUpdate, AnnouncementResponse
from uuid import UUID

router = APIRouter()

@router.get("/", response_model=list[AnnouncementResponse])
async def list_announcements(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Announcement))
    announcements = result.scalars().all()
    return announcements

@router.post("/", response_model=AnnouncementResponse, status_code=status.HTTP_201_CREATED)
async def create_announcement(payload: AnnouncementCreate, db: AsyncSession = Depends(get_db)):
    announcement = Announcement(**payload.dict())
    db.add(announcement)
    await db.commit()
    await db.refresh(announcement)
    return announcement

@router.get("/{announcement_id}", response_model=AnnouncementResponse)
async def get_announcement(announcement_id: UUID, db: AsyncSession = Depends(get_db)):
    announcement = await db.get(Announcement, announcement_id)
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    return announcement

@router.put("/{announcement_id}", response_model=AnnouncementResponse)
async def update_announcement(announcement_id: UUID, payload: AnnouncementUpdate, db: AsyncSession = Depends(get_db)):
    announcement = await db.get(Announcement, announcement_id)
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    for key, value in payload.dict(exclude_unset=True).items():
        setattr(announcement, key, value)
    await db.commit()
    await db.refresh(announcement)
    return announcement

@router.delete("/{announcement_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_announcement(announcement_id: UUID, db: AsyncSession = Depends(get_db)):
    announcement = await db.get(Announcement, announcement_id)
    if not announcement:
        raise HTTPException(status_code=404, detail="Announcement not found")
    await db.delete(announcement)
    await db.commit()
    return None
